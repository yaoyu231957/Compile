package frontend.Parser.declaration;

public interface DeclAll
{
}
