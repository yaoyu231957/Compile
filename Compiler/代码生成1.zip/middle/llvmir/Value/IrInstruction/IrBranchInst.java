package middle.llvmir.Value.IrInstruction;

import middle.llvmir.Value.IrType;

import java.util.ArrayList;

public class IrBranchInst extends IrInstruction
{
    //br i1 <cond>, label <iftrue>, label <iffalse> |
    //br label <dest>
    private String cond;
    private String iftrue;
    private String iffalse;

    public IrBranchInst(IrType type, String cond, String iftrue, String iffalse)
    {
        super(type);
        this.cond = cond;
        this.iftrue = iftrue;
        this.iffalse = iffalse;
    }

    @Override
    public ArrayList<String> irOutput()
    {
        ArrayList<String> strings = new ArrayList<>();
        return strings;
    }
}
