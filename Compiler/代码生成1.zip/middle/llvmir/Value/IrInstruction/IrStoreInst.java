package middle.llvmir.Value.IrInstruction;

import middle.llvmir.Value.IrType;
import middle.llvmir.Value.IrValue;

import java.util.ArrayList;

public class IrStoreInst extends IrInstruction
{
    //store <type> <value>,<type>* <name>
    private String name;
    private IrType type;
    private String value;
    private boolean isParam = false;

    public IrStoreInst(String name, IrType type, String value)
    {
        super(type);
        this.name = name;
        this.type = type;
        this.value = value;
    }

    public IrStoreInst(String name, IrType type, String value, boolean isParam)
    {
        super(type);
        this.name = name;
        this.type = type;
        this.value = value;
        this.isParam = isParam;
    }

    public String getName()
    {
        return name;
    }

    public ArrayList<String> irOutput()
    {
        StringBuilder sb = new StringBuilder();
        if (type == IrType.i32 || type == IrType.i8)
        {
            sb.append("store ");
            sb.append(type);
            sb.append(" ");
            sb.append(value);
            sb.append(", ");
            sb.append(type);
            sb.append("* ");
            sb.append(name);
            sb.append("\n");
        }
        else if (type == IrType.n_i8 && !isParam)
        {
            //  store [3 x i8] [i8 97, i8 98, i8 99], [3 x i8]* %a, align 1
            sb.append("store [");
            sb.append(value.length());
            sb.append(" x i8] [i8 ");
            sb.append((int) value.charAt(0));
            for (int i = 1; i < value.length(); i++)
            {
                sb.append(", i8 ");
                sb.append((int) value.charAt(i));
            }
            sb.append("], [");
            sb.append(value.length());
            sb.append(" x i8]* ");
            sb.append(name);
            sb.append(", align 1\n");
        }
        else if (type == IrType.n_i8 && isParam)
        {
            sb.append("store i8* ");
            sb.append(value);
            sb.append(", i8** ");
            sb.append(name);
            sb.append("\n");
        }
        else if (type == IrType.n_i32 && isParam)
        {
            sb.append("store i32* ");
            sb.append(value);
            sb.append(", i32** ");
            sb.append(name);
            sb.append("\n");
        }
        ArrayList<String> ret = new ArrayList<>();
        ret.add(sb.toString());
        return ret;
    }
}
