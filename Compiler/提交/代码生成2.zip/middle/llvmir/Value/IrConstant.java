package middle.llvmir.Value;

public class IrConstant
{
}
