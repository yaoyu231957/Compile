package middle.llvmir.Value.IrInstruction;

import middle.llvmir.Value.IrType;
import middle.llvmir.Value.IrValue;

public class IrGoto extends IrInstruction
{

    public IrGoto(IrType valueType)
    {
        super(valueType);
    }
}
