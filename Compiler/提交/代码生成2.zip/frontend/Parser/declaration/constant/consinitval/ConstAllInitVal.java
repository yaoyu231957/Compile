package frontend.Parser.declaration.constant.consinitval;

public interface ConstAllInitVal
{
    public String toString();
}
