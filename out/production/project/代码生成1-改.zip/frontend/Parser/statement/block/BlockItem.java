package frontend.Parser.statement.block;

public interface BlockItem
{
    public String toString();
}
