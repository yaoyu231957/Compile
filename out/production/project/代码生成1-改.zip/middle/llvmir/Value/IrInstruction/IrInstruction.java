package middle.llvmir.Value.IrInstruction;

import frontend.Parser.declaration.Decl;
import frontend.Parser.declaration.constant.ConstDecl;
import frontend.Parser.declaration.constant.ConstDef;
import frontend.Parser.declaration.constant.consinitval.*;
import frontend.Parser.declaration.variable.VarDecl;
import frontend.Parser.declaration.variable.VarDef;
import frontend.Parser.declaration.variable.variableinitval.*;
import frontend.Parser.expression.CondExp;
import frontend.Parser.expression.Exp;
import frontend.Parser.expression.FuncRParams;
import frontend.Parser.expression.arithmeticalexp.*;
import frontend.Parser.expression.primaryexp.Character;
import frontend.Parser.expression.primaryexp.ExpPrim;
import frontend.Parser.expression.primaryexp.LVal;
import frontend.Parser.expression.primaryexp.Number;
import frontend.Parser.expression.primaryexp.PrimaryAllExp;
import frontend.Parser.expression.primaryexp.PrimaryExp;
import frontend.Parser.expression.unaryexp.*;
import frontend.Parser.statement.*;
import frontend.Parser.statement.block.BlockDecl;
import frontend.Parser.statement.block.BlockItem;
import frontend.Parser.statement.block.BlockStmt;
import frontend.Parser.statement.stmtreturn.StmtReturn;
import frontend.lexer.Token;
import middle.llvmir.Value.GlobalValue.IrFunction;
import middle.llvmir.Value.GlobalValue.IrGlobalVar;
import middle.llvmir.Value.GlobalValue.IrString;
import middle.llvmir.Value.IrArgument;
import middle.llvmir.Value.IrBasicBlock;
import middle.llvmir.Value.IrType;
import middle.llvmir.Value.IrValue;
import middle.semantic.Symbol;
import middle.semantic.SymbolFunc;
import middle.semantic.SymbolTable;

import java.util.ArrayList;

public class IrInstruction extends IrValue
{
    private ArrayList<IrInstruction> irinstructions;
    private IrBasicBlock irBasicBlock;
    private SymbolTable symbolTable;
    private BlockItem blockItem;
    private CondExp condExp;
    private Stmt stmt;

    public IrInstruction(IrType type)
    {
        super(type);
    }

    public IrInstruction(IrType type, String name)
    {
        super(type, name);
    }

    public IrInstruction(IrBasicBlock irBasicBlock, SymbolTable symbolTable, BlockItem blockItem)
    {
        super(null);
        this.irBasicBlock = irBasicBlock;
        this.symbolTable = symbolTable;
        this.blockItem = blockItem;
        this.irinstructions = new ArrayList<>();
    }

    public IrInstruction(SymbolTable symbolTable, CondExp condExp)
    {
        super(null);
        this.symbolTable = symbolTable;
        this.condExp = condExp;
        this.irinstructions = new ArrayList<>();
    }

    public IrInstruction(IrBasicBlock irBasicBlock, SymbolTable symbolTable, Stmt stmt)
    {
        super(null);
        this.irBasicBlock = irBasicBlock;
        this.symbolTable = symbolTable;
        this.stmt = stmt;
        this.irinstructions = new ArrayList<>();
    }

    public ArrayList<IrInstruction> buildIrInstruction()
    {
        if (blockItem != null)
        {
            if (blockItem instanceof BlockDecl)
            {
                Decl decl = ((BlockDecl) blockItem).getDecl();
                if (decl.getValuetype().equals("const"))
                {
                    handleIRConst(decl);
                }
                else if (decl.getValuetype().equals("var"))
                {
                    handleIRVar(decl);
                }
            }
            else if (blockItem instanceof BlockStmt)
            {
                Stmt stmt = ((BlockStmt) blockItem).getStmt();
                StmtAll stmtAll = stmt.getStmt();
                if (stmtAll instanceof StmtAssign)
                {
                    // 处理 StmtAssign 类型
                    System.out.println("处理赋值语句");
                    StmtAssign stmtAssign = (StmtAssign) stmtAll;
                    handleIRAssign(stmtAssign);  // 处理赋值的中间代码生成函数
                }
                else if (stmtAll instanceof StmtBreak)
                {
                    // 处理 StmtBreak 类型
                    System.out.println("处理 break 语句");
                    StmtBreak stmtBreak = (StmtBreak) stmtAll;
                    // 这里可以添加针对 StmtBreak 类型的特定操作，比如中断循环的逻辑
                    handleIRBreak(stmtBreak);  // 假设有中间代码生成的处理函数
                }
                else if (stmtAll instanceof StmtContinue)
                {
                    // 处理 StmtContinue 类型
                    System.out.println("处理 continue 语句");
                    StmtContinue stmtContinue = (StmtContinue) stmtAll;
                    // 这里可以添加针对 StmtContinue 类型的特定操作，比如跳过当前循环
                    handleIRContinue(stmtContinue);  // 假设有处理 continue 的中间代码生成函数
                }
                else if (stmtAll instanceof StmtReturn)
                {
                    // 处理 StmtReturn 类型
                    System.out.println("处理 return 语句");
                    StmtReturn stmtReturn = (StmtReturn) stmtAll;
                    // 这里可以添加针对 StmtReturn 类型的操作，比如生成函数返回的中间代码
                    handleIRReturn(stmtReturn);  // 假设有处理 return 的中间代码生成函数
                }
                else if (stmtAll instanceof StmtPrintf)
                {
                    // 处理 StmtPrintf 类型
                    System.out.println("处理 printf 语句");
                    StmtPrintf stmtPrintf = (StmtPrintf) stmtAll;
                    // 这里可以添加针对 StmtPrintf 类型的操作，例如生成 printf 的相关代码
                    handleIRPrintf(stmtPrintf);  // 假设有处理 printf 的中间代码生成函数
                }
                else if (stmtAll instanceof StmtGet)
                {
                    // 处理 StmtGet 类型
                    System.out.println("处理 get 语句");
                    StmtGet stmtGet = (StmtGet) stmtAll;
                    // 假设 StmtGet 是用来获取输入的语句类型，可能会有输入相关的处理逻辑
                    handleIRGet(stmtGet);  // 假设有处理 get 输入的中间代码生成函数
                }
                else if (stmtAll instanceof StmtExp)
                {
                    // 处理 StmtExp 类型
                    System.out.println("处理 expression 语句");
                    StmtExp stmtExp = (StmtExp) stmtAll;
                    if (stmtExp.getExp() != null)
                    {
                        handleIRStmtExp(stmtExp);  // 处理有表达式的中间代码生成函数
                    }
                }
                else
                {
                    // 默认处理
                    System.out.println("未知的语句类型");
                }
            }
        }
        else if (stmt != null)
        {
            StmtAll stmtAll = stmt.getStmt();
            if (stmtAll instanceof StmtAssign)
            {
                // 处理 StmtAssign 类型
                System.out.println("处理赋值语句");
                StmtAssign stmtAssign = (StmtAssign) stmtAll;
                handleIRAssign(stmtAssign);  // 处理赋值的中间代码生成函数
            }
            else if (stmtAll instanceof StmtBreak)
            {
                // 处理 StmtBreak 类型
                System.out.println("处理 break 语句");
                StmtBreak stmtBreak = (StmtBreak) stmtAll;
                // 这里可以添加针对 StmtBreak 类型的特定操作，比如中断循环的逻辑
                handleIRBreak(stmtBreak);  // 假设有中间代码生成的处理函数
            }
            else if (stmtAll instanceof StmtContinue)
            {
                // 处理 StmtContinue 类型
                System.out.println("处理 continue 语句");
                StmtContinue stmtContinue = (StmtContinue) stmtAll;
                // 这里可以添加针对 StmtContinue 类型的特定操作，比如跳过当前循环
                handleIRContinue(stmtContinue);  // 假设有处理 continue 的中间代码生成函数
            }
            else if (stmtAll instanceof StmtReturn)
            {
                // 处理 StmtReturn 类型
                System.out.println("处理 return 语句");
                StmtReturn stmtReturn = (StmtReturn) stmtAll;
                // 这里可以添加针对 StmtReturn 类型的操作，比如生成函数返回的中间代码
                handleIRReturn(stmtReturn);  // 假设有处理 return 的中间代码生成函数
            }
            else if (stmtAll instanceof StmtPrintf)
            {
                // 处理 StmtPrintf 类型
                System.out.println("处理 printf 语句");
                StmtPrintf stmtPrintf = (StmtPrintf) stmtAll;
                // 这里可以添加针对 StmtPrintf 类型的操作，例如生成 printf 的相关代码
                handleIRPrintf(stmtPrintf);  // 假设有处理 printf 的中间代码生成函数
            }
            else if (stmtAll instanceof StmtGet)
            {
                // 处理 StmtGet 类型
                System.out.println("处理 get 语句");
                StmtGet stmtGet = (StmtGet) stmtAll;
                // 假设 StmtGet 是用来获取输入的语句类型，可能会有输入相关的处理逻辑
                handleIRGet(stmtGet);  // 假设有处理 get 输入的中间代码生成函数
            }
            else if (stmtAll instanceof StmtExp)
            {
                // 处理 StmtExp 类型
                System.out.println("处理 expression 语句");
                StmtExp stmtExp = (StmtExp) stmtAll;
                if (stmtExp.getExp() != null)
                {
                    handleIRStmtExp(stmtExp);  // 处理有表达式的中间代码生成函数
                }
            }
            else
            {
                // 默认处理
                System.out.println("未知的语句类型");
            }
        }
        return irinstructions;
    }

    public void handleIRConst(Decl decl)
    {
        ConstDecl constDecl = (ConstDecl) decl.getDecl();
        Token type = constDecl.getBtype().getToken();
        ArrayList<ConstDef> constDefs = constDecl.getConstDefs();

        for (ConstDef constDef : constDefs)
        {
            addConst(constDef, type);
        }

    }

    public void addConst(ConstDef constDef, Token type)
    {
        Symbol symbol = new Symbol(0, 0, constDef.getIdent().getContent(), null);
        if (constDef.getConstExp() == null && type.getType() == Token.Type.INTTK)
        {
            symbol.setType(Symbol.Type.ConstInt);
            String value = getAValue();
            symbol.setValue(value);
            symbolTable.addSymbol(symbol);
            IrAllocaInst irAllocaInst = new IrAllocaInst(value, IrType.i32, 1);
            irinstructions.add(irAllocaInst);
            symbol.setIrValue(irAllocaInst);
            if (constDef.getConstInitVal() != null)
            {
                ConstVarStore(constDef, symbol);
            }
        }
        else if (constDef.getConstExp() == null && type.getType() == Token.Type.CHARTK)
        {
            symbol.setType(Symbol.Type.ConstChar);
            String value = getAValue();
            symbol.setValue(value);
            symbolTable.addSymbol(symbol);
            IrAllocaInst irAllocaInst = new IrAllocaInst(value, IrType.i8, 1);
            irinstructions.add(irAllocaInst);
            symbol.setIrValue(irAllocaInst);
            if (constDef.getConstInitVal() != null)
            {
                ConstVarStore(constDef, symbol);
            }
        }
        else if (type.getType() == Token.Type.INTTK)
        {
            symbol.setType(Symbol.Type.ConstIntArray);
            String value = getAValue();
            symbol.setValue(value);
            symbolTable.addSymbol(symbol);
            int num = constDef.getConstExp().calcExp();
            IrAllocaInst irAllocaInst = new IrAllocaInst(value, IrType.n_i32, num);
            irinstructions.add(irAllocaInst);
            symbol.setIrValue(irAllocaInst);
            if (constDef.getConstInitVal() != null)
            {
                ConstVarStore(constDef, symbol);
            }
        }
        else if (type.getType() == Token.Type.CHARTK)
        {
            symbol.setType(Symbol.Type.ConstCharArray);
            String value = getAValue();
            symbol.setValue(value);
            symbolTable.addSymbol(symbol);
            int num = constDef.getConstExp().calcExp();
            IrAllocaInst irAllocaInst = new IrAllocaInst(value, IrType.n_i8, num);
            irinstructions.add(irAllocaInst);
            symbol.setIrValue(irAllocaInst);
            if (constDef.getConstInitVal() != null)
            {
                ConstVarStore(constDef, symbol);
            }
        }
        //setValue(constDef, symbol);
        symbolTable.addSymbol(symbol);
    }

    public void setValue(ConstDef constDef, Symbol symbol)
    {
        ConstInitVal constInitVal = constDef.getConstInitVal();
        ConIVConstExp conIVConstExp;
        switch (symbol.getType())
        {
            case ConstInt:
                conIVConstExp = (ConIVConstExp) constInitVal.getConstInitVal();
                symbol.setValue(String.valueOf(conIVConstExp.calcExp()));
                break;
            case ConstChar:
                conIVConstExp = (ConIVConstExp) constInitVal.getConstInitVal();
                symbol.setValue(String.valueOf(conIVConstExp.calcExp()));
                break;
            case ConstIntArray:
                ConIVArray conIVArray = (ConIVArray) constInitVal.getConstInitVal();
                ArrayList<String> values = new ArrayList<>();
                ArrayList<ConstExp> constExps = conIVArray.getConstExps();
                for (ConstExp constExp : constExps)
                {
                    values.add(String.valueOf(constExp.calcExp()));
                }
                symbol.setValue(values.toString());
                break;
            case ConstCharArray:
                ConIVStrConst conIVStrConst = (ConIVStrConst) constInitVal.getConstInitVal();
                symbol.setValue(conIVStrConst.getStringconst().toString());
                break;
            default:

        }
    }

    public void handleIRVar(Decl decl)
    {
        VarDecl varDecl = (VarDecl) decl.getDecl();
        Token type = varDecl.getBtype().getToken();
        ArrayList<VarDef> varDefs = varDecl.getVarDefs();
        for (VarDef varDef : varDefs)
        {
            addVar(varDef, type);
        }
    }

    public void addVar(VarDef varDef, Token type)
    {
        Symbol symbol = new Symbol(0, 0, varDef.getIdent().getContent(), null);
        if (varDef.getConstExp() == null && type.getType() == Token.Type.INTTK)
        {
            symbol.setType(Symbol.Type.Int);
            String value = getAValue();
            symbol.setValue(value);
            symbolTable.addSymbol(symbol);
            IrAllocaInst irAllocaInst = new IrAllocaInst(value, IrType.i32, 1);
            irinstructions.add(irAllocaInst);
            symbol.setIrValue(irAllocaInst);
            if (varDef.getVarInitVal() != null)
            {
                VarStore(varDef, symbol);
            }
        }
        else if (varDef.getConstExp() == null && type.getType() == Token.Type.CHARTK)
        {
            symbol.setType(Symbol.Type.Char);
            String value = getAValue();
            symbol.setValue(value);
            symbolTable.addSymbol(symbol);
            IrAllocaInst irAllocaInst = new IrAllocaInst(value, IrType.i8, 1);
            irinstructions.add(irAllocaInst);
            symbol.setIrValue(irAllocaInst);
            if (varDef.getVarInitVal() != null)
            {
                VarStore(varDef, symbol);
            }
        }
        else if (type.getType() == Token.Type.INTTK)
        {
            symbol.setType(Symbol.Type.IntArray);
            String value = getAValue();
            symbol.setValue(value);
            symbolTable.addSymbol(symbol);
            int num = varDef.getConstExp().calcExp();
            IrAllocaInst irAllocaInst = new IrAllocaInst(value, IrType.n_i32, num);
            irinstructions.add(irAllocaInst);
            symbol.setIrValue(irAllocaInst);
            if (varDef.getVarInitVal() != null)
            {
                ArrayStore(num, varDef, symbol);
            }
        }
        else if (type.getType() == Token.Type.CHARTK)
        {
            symbol.setType(Symbol.Type.CharArray);
            String value = getAValue();
            symbol.setValue(value);
            symbolTable.addSymbol(symbol);
            int num = varDef.getConstExp().calcExp();
            IrAllocaInst irAllocaInst = new IrAllocaInst(value, IrType.n_i8, num);
            irinstructions.add(irAllocaInst);
            symbol.setIrValue(irAllocaInst);
            if (varDef.getVarInitVal() != null)
            {
                ArrayStore(num, varDef, symbol);
            }
        }
        symbolTable.addSymbol(symbol);
    }

    public void ConstVarStore(ConstDef constDef, Symbol symbol)
    {
        ConstAllInitVal constAllInitVal = constDef.getConstInitVal().getConstInitVal();
        ConIVConstExp conIVConstExp = (ConIVConstExp) constAllInitVal;
        IrValue irValue = handleIRConstExp(conIVConstExp.getConstExp(), false);
        IrStoreInst irStoreInst = null;
        if (symbol.getType() == Symbol.Type.ConstInt)
        {
            if (irValue.getValueType() != IrType.i32)
            {
                String value_zext = getAValue();
                IrZext irZext = new IrZext(IrType.i8, value_zext, irValue, IrType.i32);
                irValue = irZext;
                irinstructions.add(irZext);
            }
            //修改
            //irStoreInst = new IrStoreInst(symbol.getValue(), IrType.i32, irValue);
            irStoreInst = new IrStoreInst(symbol.getIrValue(), IrType.i32, irValue);
        }
        else if (symbol.getType() == Symbol.Type.ConstChar)
        {
            if (irValue.getValueType() != IrType.i8)
            {
                String value_trunc = getAValue();
                IrTrunc irTrunc = new IrTrunc(IrType.i32, value_trunc, irValue, IrType.i8);
                irValue = irTrunc;
                irinstructions.add(irTrunc);
            }
            //修改
            irStoreInst = new IrStoreInst(symbol.getValue(), IrType.i8, irValue);
            //irStoreInst = new IrStoreInst(symbol.getIrValue(), IrType.i8, irValue);
        }
        symbol.setIrValue(irStoreInst);
        irinstructions.add(irStoreInst);
    }

    public void VarStore(VarDef varDef, Symbol symbol)
    {
        VarAllInitVal varAllInitVal = varDef.getVarInitVal().getVarInitVal();
        VarIVExp varIVExp = (VarIVExp) varAllInitVal;
        IrValue irValue = handleIRExp(varIVExp.getExp(), false);
        IrStoreInst irStoreInst = null;
        if (symbol.getType() == Symbol.Type.Int)
        {
            if (irValue.getValueType() != IrType.i32)
            {
                String value_zext = getAValue();
                IrZext irZext = new IrZext(IrType.i8, value_zext, irValue, IrType.i32);
                irValue = irZext;
                irinstructions.add(irZext);
            }
            //修改
            //irStoreInst = new IrStoreInst(symbol.getValue(), IrType.i32, irValue);
            irStoreInst = new IrStoreInst(symbol.getIrValue(), IrType.i32, irValue);
        }
        else if (symbol.getType() == Symbol.Type.Char)
        {
            if (irValue.getValueType() != IrType.i8)
            {
                String value_trunc = getAValue();
                IrTrunc irTrunc = new IrTrunc(IrType.i32, value_trunc, irValue, IrType.i8);
                irValue = irTrunc;
                irinstructions.add(irTrunc);
            }
            //修改
            irStoreInst = new IrStoreInst(symbol.getValue(), IrType.i8, irValue);
            //irStoreInst = new IrStoreInst(symbol.getIrValue(), IrType.i8, irValue);
        }
        symbol.setIrValue(irStoreInst);
        irinstructions.add(irStoreInst);
    }

    public void ArrayStore(int num, VarDef varDef, Symbol symbol)
    {
        VarInitVal varInitVal = varDef.getVarInitVal();
        if (symbol.getType() == Symbol.Type.IntArray)
        {
            VarIVArray varIVArray = (VarIVArray) varInitVal.getVarInitVal();
            ArrayList<Exp> exps = varIVArray.getExps();
            for (int i = 0; i < num; i++)
            {
                String value = getAValue();
                IrValue irValue = null;
                if (i < exps.size())
                {
                    irValue = handleIRExp(exps.get(i), false);
                }
                else
                {
                    irValue = new IrValue(IrType.i32, "0");
                }
                IrGetelement irGetelement = new IrGetelement(value, IrType.i32, symbol.getIrValue(), String.valueOf(i));
                irinstructions.add(irGetelement);
                if (irValue.getValueType() != IrType.i32)
                {
                    String value_zext = getAValue();
                    IrZext irZext = new IrZext(IrType.i8, value_zext, irValue, IrType.i32);
                    irValue = irZext;
                    irinstructions.add(irZext);
                }
                //修改
                //IrStoreInst irStoreInst = new IrStoreInst(value, IrType.i32, irValue);
                IrStoreInst irStoreInst = new IrStoreInst(irGetelement, IrType.i32, irValue);
                irinstructions.add(irStoreInst);
            }
        }
        else if (symbol.getType() == Symbol.Type.CharArray)
        {
            if (varInitVal.getVarInitVal() instanceof VarIVStrConst)
            {
                VarIVStrConst varIVStrConst = (VarIVStrConst) varInitVal.getVarInitVal();
                Token string = varIVStrConst.getStringconst();
                String s = string.getContent();
                s = s.substring(1, s.length() - 1);
                StringBuilder sb = new StringBuilder(s);
                // 计算需要补充的零的个数
                int zerosToAdd = num - s.length();
                // 在字符串末尾添加零
                for (int i = 0; i < zerosToAdd; i++)
                {
                    sb.append('0');
                }
                s = sb.toString();
                IrStoreInst irStoreInst = new IrStoreInst(symbol.getIrValue(), IrType.n_i8, s);
                irinstructions.add(irStoreInst);
            }
            else if (varInitVal.getVarInitVal() instanceof VarIVArray)
            {
                VarIVArray varIVArray = (VarIVArray) varInitVal.getVarInitVal();
                ArrayList<Exp> exps = varIVArray.getExps();
                for (int i = 0; i < num; i++)
                {
                    String value = getAValue();
                    IrValue irValue = null;
                    if (i < exps.size())
                    {
                        irValue = handleIRExp(exps.get(i), false);
                    }
                    else
                    {
                        irValue = new IrValue(IrType.i8, "0");
                    }
                    IrGetelement irGetelement = new IrGetelement(value, IrType.i8, symbol.getIrValue(), String.valueOf(i));
                    irinstructions.add(irGetelement);
                    if (irValue.getValueType() != IrType.i8)
                    {
                        String value_trunc = getAValue();
                        IrTrunc irTrunc = new IrTrunc(IrType.i32, value_trunc, irValue, IrType.i8);
                        irValue = irTrunc;
                        irinstructions.add(irTrunc);
                    }
                    //修改
                    //IrStoreInst irStoreInst = new IrStoreInst(value, IrType.i8, irValue);
                    IrStoreInst irStoreInst = new IrStoreInst(irGetelement, IrType.i8, irValue);
                    irinstructions.add(irStoreInst);
                }
            }

        }
    }

    public IrValue handleIRExp(Exp exp, boolean isLeft)
    {
        return handleIRAddExp(exp.getExp(), isLeft);
    }

    public IrValue handleIRConstExp(ConstExp constExp, boolean isLeft)
    {
        return handleIRAddExp(constExp.getExp(), isLeft);
    }

    public IrValue handleIRAddExp(AddExp addExp, boolean isLeft)
    {
        ArrayList<MulExp> mulExps = addExp.getExps();
        ArrayList<Token> ops = addExp.getOps();
        IrValue first = handleIRMulExp(mulExps.get(0), isLeft);
        if (ops.isEmpty())
        {
            return first;
        }
        else
        {
            IrValue exp1 = first;
            IrValue exp2 = null;
            for (int i = 0; i < ops.size(); i++)
            {
                exp2 = handleIRMulExp(mulExps.get(i + 1), isLeft);
                if (exp1.getValueType() == IrType.i8)
                {
                    String value = getAValue();
                    IrZext irZext = new IrZext(IrType.i8, value, exp1, IrType.i32);
                    irinstructions.add(irZext);
                    exp1 = irZext;
                }
                if (exp2.getValueType() == IrType.i8)
                {
                    String value = getAValue();
                    IrZext irZext = new IrZext(IrType.i8, value, exp2, IrType.i32);
                    irinstructions.add(irZext);
                    exp2 = irZext;
                }
                IrBinaryOperator irBinaryOperator = null;
                if (ops.get(i).getType() == Token.Type.PLUS)
                {
                    irBinaryOperator = new IrBinaryOperator(getAValue(), IrBinaryOperator.Type.Add, IrType.i32, exp1, exp2);
                }
                else if (ops.get(i).getType() == Token.Type.MINU)
                {
                    irBinaryOperator = new IrBinaryOperator(getAValue(), IrBinaryOperator.Type.Sub, IrType.i32, exp1, exp2);
                }
                irinstructions.add(irBinaryOperator);
                exp1 = irBinaryOperator;
                first = irBinaryOperator;
            }
            return first;
        }
    }

    public IrValue handleIRMulExp(MulExp mulExp, boolean isLeft)
    {
        ArrayList<UnaryExp> unaryExps = mulExp.getExps();
        ArrayList<Token> ops = mulExp.getOps();
        IrValue first = handleIRUnaryExp(unaryExps.get(0), isLeft);
        if (ops.isEmpty())
        {
            return first;
        }
        else
        {
            IrValue exp1 = first;
            IrValue exp2 = null;
            for (int i = 0; i < ops.size(); i++)
            {
                exp2 = handleIRUnaryExp(unaryExps.get(i + 1), isLeft);
                if (exp1.getValueType() == IrType.i8)
                {
                    String value = getAValue();
                    IrZext irZext = new IrZext(IrType.i8, value, exp1, IrType.i32);
                    irinstructions.add(irZext);
                    exp1 = irZext;
                }
                if (exp2.getValueType() == IrType.i8)
                {
                    String value = getAValue();
                    IrZext irZext = new IrZext(IrType.i8, value, exp2, IrType.i32);
                    irinstructions.add(irZext);
                    exp2 = irZext;
                }
                IrBinaryOperator irBinaryOperator = null;
                if (ops.get(i).getType() == Token.Type.MULT)
                {
                    irBinaryOperator = new IrBinaryOperator(getAValue(), IrBinaryOperator.Type.Mul, IrType.i32, exp1, exp2);
                }
                else if (ops.get(i).getType() == Token.Type.DIV)
                {
                    irBinaryOperator = new IrBinaryOperator(getAValue(), IrBinaryOperator.Type.Div, IrType.i32, exp1, exp2);
                }
                else if (ops.get(i).getType() == Token.Type.MOD)
                {
                    irBinaryOperator = new IrBinaryOperator(getAValue(), IrBinaryOperator.Type.Mod, IrType.i32, exp1, exp2);
                }
                irinstructions.add(irBinaryOperator);
                first = irBinaryOperator;
                exp1 = irBinaryOperator;
            }
            return first;
        }
    }

    public IrValue handleIRUnaryExp(UnaryExp unaryExp, boolean isLeft)
    {
        UnaryAll unaryexp = unaryExp.getUnaryexp();
        IrValue irValue = null;
        if (unaryexp instanceof UnaryPriExp)
        {
            UnaryPriExp unaryPriExp = (UnaryPriExp) unaryexp;
            irValue = handleUnaryPrim(unaryPriExp, isLeft);
        }
        else if (unaryexp instanceof UnaryFunc)
        {
            UnaryFunc unaryFunc = (UnaryFunc) unaryexp;
            irValue = handleUnaryFunc(unaryFunc, isLeft);
        }
        else if (unaryexp instanceof UnaryOp)
        {
            UnaryOp unaryOp = (UnaryOp) unaryexp;
            irValue = handleUnaryOp(unaryOp, isLeft);
        }
        else
        {
            System.out.println("UnaryExp error");
        }
        return irValue;
    }


    public IrValue handleUnaryPrim(UnaryPriExp unaryPriExp, boolean isLeft)
    {
        PrimaryAllExp primaryExp = unaryPriExp.getExp().getExp();
        IrValue irValue = null;
        if (primaryExp instanceof ExpPrim)
        {
            ExpPrim expPrim = (ExpPrim) primaryExp;
            irValue = handleIRExpPrim(expPrim, isLeft);
        }
        else if (primaryExp instanceof LVal)
        {
            LVal lVal = (LVal) primaryExp;
            irValue = handleIRLVal(lVal, false);
        }
        else if (primaryExp instanceof Number)
        {
            Number number = (Number) primaryExp;
            irValue = handleNumber(number);
        }
        else if (primaryExp instanceof Character)
        {
            Character character = (Character) primaryExp;
            irValue = handleCharacter(character);
        }
        else
        {
            System.out.println("UnaryPrim Error");
        }
        return irValue;
    }

    public IrValue handleIRLVal(LVal lVal, boolean isLeft)
    {
        IrValue irValue = null;
        String name = lVal.getIdent().getContent();
        Exp exp = lVal.getExp();
        if (exp == null)
        {
            Symbol symbol = symbolTable.getSymbol(name);
            if (isLeft)
            {
                irValue = symbol.getIrValue();
                if (irValue.isParam())
                {
                    IrValue left = irValue;
                    String value = null;
                    IrAllocaInst irAllocaInst = null;
                    if (symbol.getType() == Symbol.Type.Int)
                    {
                        left = new IrValue(IrType.i32);
                        value = getAValue();
                        irAllocaInst = new IrAllocaInst(value, IrType.i32, 1);
                        left.setName(name);
                        irinstructions.add(irAllocaInst);
                        //修改
                        //IrStoreInst irStoreInst = new IrStoreInst(value, IrType.i32, irValue.getName());
                        IrStoreInst irStoreInst = new IrStoreInst(irAllocaInst, IrType.i32, irValue);
                        irinstructions.add(irStoreInst);
                        irValue = irStoreInst;
                    }
                    else if (symbol.getType() == Symbol.Type.Char)
                    {
                        left = new IrValue(IrType.i8);
                        value = getAValue();
                        irAllocaInst = new IrAllocaInst(value, IrType.i8, 1);
                        left.setName(name);
                        irinstructions.add(irAllocaInst);
                        //修改
                        //IrStoreInst irStoreInst = new IrStoreInst(value, IrType.i8, irValue.getName());
                        IrStoreInst irStoreInst = new IrStoreInst(irAllocaInst, IrType.i8, irValue);
                        irStoreInst.setName(name);
                        irinstructions.add(irStoreInst);
                        irValue = irStoreInst;
                    }
                }
                return irValue;
            }
            else
            {
                IrValue ptr = symbol.getIrValue();
                String name1 = ptr.getName();
                if (!(ptr.getName().contains("%") || ptr.getName().contains("@")))
                {
                    return ptr;
                }

                if (ptr.isParam())
                {
                    String value_alloca = irBasicBlock.getFunction().getAValue();
                    IrAllocaInst irAllocaInst = new IrAllocaInst(value_alloca, ptr.getValueType(), 1, true);
                    //修改
                    //IrStoreInst irStoreInst = new IrStoreInst(value_alloca, ptr.getValueType(), name1, true);
                    IrStoreInst irStoreInst = new IrStoreInst(irAllocaInst, ptr.getValueType(), ptr, true);
                    String value_load = irBasicBlock.getFunction().getAValue();
                    IrLoadInst irLoadInst = new IrLoadInst(value_load, ptr.getValueType(), irAllocaInst);
                    irinstructions.add(irAllocaInst);
                    irinstructions.add(irStoreInst);
                    irinstructions.add(irLoadInst);
                    return irLoadInst;
                }

                // 全局/局部变量，需要从内存中读取
                String value = getAValue();
                IrValue irValue_ret = null;
                if (symbol.getType() == Symbol.Type.Int || symbol.getType() == Symbol.Type.ConstInt)
                {
                    IrLoadInst irLoadInst = new IrLoadInst(value, IrType.i32, ptr);
                    irinstructions.add(irLoadInst);
                    irValue_ret = irLoadInst;
                }
                else if (symbol.getType() == Symbol.Type.Char || symbol.getType() == Symbol.Type.ConstChar)
                {
                    IrLoadInst irLoadInst = new IrLoadInst(value, IrType.i8, ptr);
                    irinstructions.add(irLoadInst);
                    irValue_ret = irLoadInst;
                }
                else if (symbol.getType() == Symbol.Type.IntArray || symbol.getType() == Symbol.Type.ConstIntArray)
                {
                    //todo
                    //直接返回数组对象
                    IrGetelement irGetelement = new IrGetelement(value, IrType.n_i32, ptr, "0");
                    irinstructions.add(irGetelement);
                    irValue_ret = irGetelement;
                }
                else if (symbol.getType() == Symbol.Type.CharArray || symbol.getType() == Symbol.Type.ConstCharArray)
                {
                    //todo
                    //直接返回数组对象
                    IrGetelement irGetelement = new IrGetelement(value, IrType.n_i8, ptr, "0");
                    irinstructions.add(irGetelement);
                    irValue_ret = irGetelement;
                }
                return irValue_ret;
            }
        }
        else
        {
            Symbol symbol = symbolTable.getSymbol(name);
            if (isLeft)
            {
                //todo
                //数组变量在左边
                irValue = symbol.getIrValue();
                if (irValue.isParam())
                {
                    IrValue left = null;
                    String value = null;
                    IrAllocaInst irAllocaInst = null;
                    left = new IrValue(irValue.getValueType());
                    value = getAValue();
                    irAllocaInst = new IrAllocaInst(value, irValue.getValueType(), 1, true);
                    left.setName(name);
                    irinstructions.add(irAllocaInst);
                    IrStoreInst irStoreInst = new IrStoreInst(irAllocaInst, irValue.getValueType(), irValue, true);
                    irStoreInst.setName(name);
                    irinstructions.add(irStoreInst);
                    irValue = irStoreInst;
                }
                String value = getAValue();
                IrGetelement irGetelement = null;
                IrLoadInst irLoadInst = null;
                IrValue offset = handleIRExp(exp, isLeft);
                if (symbol.getType() == Symbol.Type.IntArray || symbol.getType() == Symbol.Type.ConstIntArray)
                {
                    irGetelement = new IrGetelement(value, IrType.i32, irValue, offset.getName());
                    //String value1 = getAValue();
                    //irLoadInst = new IrLoadInst(value1, IrType.i32, irGetelement, true);
                    //irValue = irLoadInst;
                    irValue = irGetelement;
                }
                else if (symbol.getType() == Symbol.Type.CharArray || symbol.getType() == Symbol.Type.ConstCharArray)
                {
                    irGetelement = new IrGetelement(value, IrType.i8, irValue, offset.getName());
                    //String value1 = getAValue();
                    //irLoadInst = new IrLoadInst(value1, IrType.i8, irGetelement, true);
                    //irValue = irLoadInst;
                    irValue = irGetelement;
                }
                irinstructions.add(irGetelement);
                //irinstructions.add(irLoadInst);
                return irValue;
            }
            else
            {
                IrValue ptr = symbol.getIrValue();
                String name1 = ptr.getName();
                if (ptr.isParam())
                {
                    String value_alloca = irBasicBlock.getFunction().getAValue();
                    IrAllocaInst irAllocaInst = new IrAllocaInst(value_alloca, ptr.getValueType(), 1, true);
                    //修改
                    //IrStoreInst irStoreInst = new IrStoreInst(value_alloca, ptr.getValueType(), name1, true);
                    IrStoreInst irStoreInst = new IrStoreInst(irAllocaInst, ptr.getValueType(), ptr, true);
                    String value_load = irBasicBlock.getFunction().getAValue();
                    IrLoadInst irLoadInst = new IrLoadInst(value_load, ptr.getValueType(), irAllocaInst);
                    irinstructions.add(irAllocaInst);
                    irinstructions.add(irStoreInst);
                    irinstructions.add(irLoadInst);
                    symbol.setIrValue(irLoadInst);
                    ptr = irLoadInst;
                }
                String value = getAValue();
                IrGetelement irGetelement = null;
                IrLoadInst irLoadInst = null;
                IrValue offset = handleIRExp(exp, isLeft);
                //todo
                //不知道全局数组变量是不是一样
                if (symbol.getType() == Symbol.Type.IntArray || symbol.getType() == Symbol.Type.ConstIntArray)
                {
                    irGetelement = new IrGetelement(value, IrType.n_i32, ptr, offset.getName());
                    String value1 = getAValue();
                    irLoadInst = new IrLoadInst(value1, IrType.i32, irGetelement);
                }
                else if (symbol.getType() == Symbol.Type.CharArray || symbol.getType() == Symbol.Type.ConstCharArray)
                {
                    irGetelement = new IrGetelement(value, IrType.n_i8, ptr, offset.getName());
                    String value1 = getAValue();
                    irLoadInst = new IrLoadInst(value1, IrType.i8, irGetelement);
                }
                irinstructions.add(irGetelement);
                irinstructions.add(irLoadInst);
                return irLoadInst;
            }

        }
    }

    public IrValue handleIRExpPrim(ExpPrim expPrim, boolean isLeft)
    {
        Exp exp = expPrim.getExp();
        return handleIRExp(exp, isLeft);
    }

    public IrValue handleNumber(Number number)
    {
        String num = number.getIntconst().getContent();
        IrValue irValue = new IrValue(IrType.i32, num);
        return irValue;
    }

    public IrValue handleCharacter(Character character)
    {
        String cha = character.getCharconst().getContent();
        int c = cha.charAt(1);
        IrValue irValue = new IrValue(IrType.i8, String.valueOf(c));
        return irValue;
    }

    public IrValue handleUnaryFunc(UnaryFunc unaryFunc, boolean isLeft)
    {
        IrCallInst irCallInst = null;
        String name = unaryFunc.getName().getContent();
        FuncRParams funcRParams = unaryFunc.getFuncRParams();
        ArrayList<IrValue> args = new ArrayList<>();
        Symbol symbol = symbolTable.getSymbol(name);
        IrFunction irFunction = (IrFunction) symbol.getIrValue();
        if (funcRParams.getExps().isEmpty())
        {
            if (symbol.getType() == Symbol.Type.IntFunc)
            {
                irCallInst = new IrCallInst(IrType.i32, irFunction, args);
            }
            else if (symbol.getType() == Symbol.Type.CharFunc)
            {
                irCallInst = new IrCallInst(IrType.i8, irFunction, args);
            }
            else if (symbol.getType() == Symbol.Type.VoidFunc)
            {
                irCallInst = new IrCallInst(IrType.Void, irFunction, args);
            }
        }
        else
        {
            SymbolFunc symbolFunc = (SymbolFunc) symbol;
            ArrayList<Symbol> symbols = symbolFunc.getSymbols();
            ArrayList<Exp> exps = funcRParams.getExps();
            IrValue arg = null;
            int i = 0;
            for (Exp exp : exps)
            {
                Symbol symbol1 = symbols.get(i);
                if (symbol1.getType() != Symbol.Type.Int && symbol1.getType() != Symbol.Type.Char)
                {
                    /* 对待参数中的数组部分 */
                    arg = handleIRExp(exp, true);
                    if (symbol1.getType() == Symbol.Type.Int && arg.getValueType() != IrType.i32)
                    {
                        String value = getAValue();
                        IrZext irZext = new IrZext(IrType.i8, value, arg, IrType.i32);
                        irinstructions.add(irZext);
                        arg = irZext;
                    }
                    else if (symbol1.getType() == Symbol.Type.Char && arg.getValueType() != IrType.i8)
                    {
                        String value = getAValue();
                        IrTrunc irTrunc = new IrTrunc(IrType.i32, value, arg, IrType.i8);
                        irinstructions.add(irTrunc);
                        arg = irTrunc;
                    }
                    args.add(arg);
                }
                else
                {
                    /* 对待参数中的非数组部分 */
                    arg = handleIRExp(exp, false);
                    if (symbol1.getType() == Symbol.Type.Int && arg.getValueType() != IrType.i32)
                    {
                        String value = getAValue();
                        IrZext irZext = new IrZext(IrType.i8, value, arg, IrType.i32);
                        irinstructions.add(irZext);
                        arg = irZext;
                    }
                    else if (symbol1.getType() == Symbol.Type.Char && arg.getValueType() != IrType.i8)
                    {
                        String value = getAValue();
                        IrTrunc irTrunc = new IrTrunc(IrType.i32, value, arg, IrType.i8);
                        irinstructions.add(irTrunc);
                        arg = irTrunc;
                    }
                    args.add(arg);
                    /*
                    IrValue left = null;
                    String value = null;
                    IrAllocaInst irAllocaInst = null;
                    if (symbol1.getType() == Symbol.Type.Int)
                    {
                        left = new IrValue(IrType.i32);
                        value = getAValue();
                        irAllocaInst = new IrAllocaInst(value, IrType.i32, 1);
                        left.setName(name);
                        irAllocaInst.setName(name);
                        irinstructions.add(irAllocaInst);
                        IrStoreInst irStoreInst = new IrStoreInst(value, IrType.i32, arg.getName());
                        irStoreInst.setName(name);
                        irinstructions.add(irStoreInst);
                        args.add(irStoreInst);
                    }
                    else if (symbol1.getType() == Symbol.Type.Char)
                    {
                        left = new IrValue(IrType.i8);
                        value = getAValue();
                        irAllocaInst = new IrAllocaInst(value, IrType.i8, 1);
                        left.setName(name);
                        irAllocaInst.setName(name);
                        irinstructions.add(irAllocaInst);
                        IrStoreInst irStoreInst = new IrStoreInst(value, IrType.i8, arg.getName());
                        irStoreInst.setName(name);
                        irinstructions.add(irStoreInst);
                        args.add(irStoreInst);
                    }

                     */
                }
                i++;
            }
            if (symbol.getType() == Symbol.Type.IntFunc)
            {
                irCallInst = new IrCallInst(IrType.i32, irFunction, args);
            }
            else if (symbol.getType() == Symbol.Type.CharFunc)
            {
                irCallInst = new IrCallInst(IrType.i8, irFunction, args);
            }
            else if (symbol.getType() == Symbol.Type.VoidFunc)
            {
                irCallInst = new IrCallInst(IrType.Void, irFunction, args);
            }
        }
        if (symbol.getType() != Symbol.Type.VoidFunc)
        {
            String value = getAValue();
            irCallInst.setResult(value);
        }
        irinstructions.add(irCallInst);
        return irCallInst;
    }

    public IrValue handleUnaryOp(UnaryOp unaryOp, boolean isLeft)
    {
        UnaryExp unaryExp = unaryOp.getExp();
        Token op = unaryOp.getOp();
        IrValue irValue = null;
        if (op.getType() == Token.Type.PLUS)
        {
            irValue = handleIRUnaryExp(unaryExp, isLeft);
        }
        else if (op.getType() == Token.Type.MINU)
        {
            IrValue left = new IrValue(IrType.i32, "0");
            IrBinaryOperator irBinaryOperator = new IrBinaryOperator(null, IrBinaryOperator.Type.Sub, IrType.i32, left, handleIRUnaryExp(unaryExp, isLeft));
            String value = getAValue();
            irBinaryOperator.setResult(value);
            irValue = irBinaryOperator;
            irinstructions.add(irBinaryOperator);
        }
        else if (op.getType() == Token.Type.NOT)
        {
            IrBinaryOperator irBinaryOperator = new IrBinaryOperator(null, IrBinaryOperator.Type.Not, IrType.i32, handleIRUnaryExp(unaryExp, isLeft), null);
            String value = getAValue();
            irBinaryOperator.setResult(value);
            irValue = irBinaryOperator;
            irinstructions.add(irBinaryOperator);
        }
        return irValue;
    }

    public void handleIRAssign(StmtAssign stmtAssign)
    {
        LVal lVal = stmtAssign.getlVal();
        Exp exp = stmtAssign.getExp();
        IrValue left = handleIRLVal(lVal, true);
        IrValue right = handleIRExp(exp, false);
        IrStoreInst irStoreInst = null;
        Symbol symbol = symbolTable.getSymbol(lVal.getIdent().getContent());
        if (left.getValueType() == IrType.i8 && right.getValueType() == IrType.i32)
        {
            String value = getAValue();
            IrTrunc irTrunc = new IrTrunc(right.getValueType(), value, right, left.getValueType());
            irinstructions.add(irTrunc);
            right = irTrunc;
        }
        if (left.getValueType() == IrType.i32 && right.getValueType() == IrType.i8)
        {
            String value = getAValue();
            IrZext irZext = new IrZext(right.getValueType(), value, right, left.getValueType());
            irinstructions.add(irZext);
            right = irZext;
        }
        if (lVal.getExp() == null)
        {
            if (lVal.getValuetype().equals("int"))
            {
                irStoreInst = new IrStoreInst(left, IrType.i32, right);
            }
            else
            {
                irStoreInst = new IrStoreInst(left, IrType.i8, right);
            }
            symbol.setIrValue(irStoreInst);
        }
        else
        {
            Exp exp1 = lVal.getExp();
            IrValue offset = handleIRExp(exp1, false);
            String value = getAValue();
            IrGetelement irGetelement = null;
            if (lVal.getValuetype().equals("int"))
            {
                irStoreInst = new IrStoreInst(left, IrType.i32, right);
                /*
                irGetelement = new IrGetelement(value, IrType.i32, left.getName(), offset.getName());
                irStoreInst = new IrStoreInst(right.getName(), IrType.i32, value);

                 */
            }
            else
            {
                irStoreInst = new IrStoreInst(left, IrType.i8, right);
                /*
                irGetelement = new IrGetelement(value, IrType.i8, left.getName(), offset.getName());
                irStoreInst = new IrStoreInst(right.getName(), IrType.i8, value);

                 */
            }
            //irinstructions.add(irGetelement);
        }
        irinstructions.add(irStoreInst);
    }

    public void handleIRBreak(StmtBreak stmtBreak)
    {
        //todo
        IrGoto irGoto = new IrGoto(IrType.i32);
        irinstructions.add(irGoto);
    }

    public void handleIRContinue(StmtContinue stmtContinue)
    {
        //todo
        IrGoto irGoto = new IrGoto(IrType.i32);
        irinstructions.add(irGoto);
    }

    public void handleIRReturn(StmtReturn stmtReturn)
    {
        Exp exp = stmtReturn.getExp();
        IrValue irValue = new IrValue(IrType.Void);
        if (exp != null)
        {
            irValue = handleIRExp(exp, false);
        }
        String value = getAValue();
        if (irValue.getValueType() != irBasicBlock.getFunction().getValueType())
        {
            if (irValue.getValueType() == IrType.i8)
            {
                IrZext irZext = new IrZext(IrType.i8, value, irValue, IrType.i32);
                irinstructions.add(irZext);
                irValue = irZext;
            }
            else if (irValue.getValueType() == IrType.i32)
            {
                IrTrunc irTrunc = new IrTrunc(IrType.i32, value, irValue, IrType.i8);
                irinstructions.add(irTrunc);
                irValue = irTrunc;
            }
        }
        IrReturnInst irReturnInst = new IrReturnInst(irValue);
        irinstructions.add(irReturnInst);
    }

    public void handleIRGet(StmtGet stmtGet)
    {
        LVal lVal = stmtGet.getlVal();
        Token gettk = stmtGet.getGettk();
        IrValue left = handleIRLVal(lVal, true);
        String value = getAValue();
        IrCallInst irCallInst = null;
        if (gettk.getType() == Token.Type.GETINTTK)
        {
            irCallInst = new IrCallInst("getint");
        }
        else if (gettk.getType() == Token.Type.GETCHARTK)
        {
            irCallInst = new IrCallInst("getchar");
        }
        irCallInst.setResult(value);
        irinstructions.add(irCallInst);
        IrStoreInst irStoreInst = null;
        IrValue value_store = irCallInst;
        if (left.getValueType() != IrType.i32)
        {
            String value_trunc = getAValue();
            IrTrunc irTrunc = new IrTrunc(IrType.i32, value_trunc, irCallInst, IrType.i8);
            irinstructions.add(irTrunc);
            value_store = irTrunc;
        }
        if (lVal.getValuetype().equals("int") || lVal.getValuetype().equals("char"))
        {
            //
            irStoreInst = new IrStoreInst(left, left.getValueType(), value_store);
        }
        else
        {
            Exp exp = lVal.getExp();
            IrValue offset = handleIRExp(exp, false);
            String result = getAValue();
            //修改
            IrGetelement irGetelement = new IrGetelement(result, left.getValueType(), left, offset.getName());
            //IrGetelement irGetelement = new IrGetelement(result, left.getValueType(), lVal.getIdent().getContent(), offset.getName());
            irinstructions.add(irGetelement);
            irStoreInst = new IrStoreInst(irGetelement, irCallInst.getValueType(), value_store);
        }
        irinstructions.add(irStoreInst);
    }

    public void handleIRPrintf(StmtPrintf stmtPrintf)
    {
        Token stringconst = stmtPrintf.getStringconst();
        ArrayList<Exp> exps = stmtPrintf.getExps();
        String string = stringconst.getContent();
        char[] chars = string.substring(1, string.length() - 1).toCharArray();
        int cnt = 0;

        ArrayList<IrValue> values = new ArrayList<>();
        /* 首先将exps处理出来 */
        for (int i = 0; i < exps.size(); i++)
        {
            Exp exp = exps.get(i);
            IrValue irexp = handleIRExp(exp, false);
            values.add(irexp);
        }
        for (int i = 0; i < chars.length; i++)
        {
            char c = chars[i];
            IrCallInst irCallInst = null;
            if (c == '%')
            {
                if (chars[i + 1] == 'd')
                {
                    IrValue value = values.get(cnt);
                    if (value.getValueType() != IrType.i32)
                    {
                        String value1 = getAValue();
                        IrZext irZext = new IrZext(IrType.i8, value1, value, IrType.i32);
                        irinstructions.add(irZext);
                        value = irZext;
                    }
                    irCallInst = new IrCallInst("putint", value);
                    cnt++;
                    i++;
                }
                else if (chars[i + 1] == 'c')
                {
                    IrValue value = values.get(cnt);
                    if (value.getValueType() != IrType.i32)
                    {
                        String value1 = getAValue();
                        IrZext irZext = new IrZext(IrType.i8, value1, value, IrType.i32);
                        irinstructions.add(irZext);
                        value = irZext;
                    }
                    irCallInst = new IrCallInst("putch", value);
                    cnt++;
                    i++;
                }
            }
            else if (c == '\\' && chars[i + 1] == 'n')
            {
                if (!IrString.getHas_n())
                {
                    IrString irString = new IrString("\\n");
                    irBasicBlock.getFunction().getIrModule().addIrGlobalVar(irString);
                    irCallInst = new IrCallInst("putstr", irString.getParam());
                    IrString.setIrString(irString);
                }
                else
                {
                    IrString irString = IrString.getIrString();
                    irCallInst = new IrCallInst("putstr", irString.getParam());
                }
                i += 1;
            }
            else
            {
                StringBuilder sb = new StringBuilder();
                while (c != '%')
                {
                    sb.append(c);
                    i++;
                    if (i >= chars.length)
                    {
                        break;
                    }
                    c = chars[i];
                }
                i--;
                String s = sb.toString();
                //s.replaceAll("\n", "\0A");
                IrString irString = new IrString(s);
                irBasicBlock.getFunction().getIrModule().addIrGlobalVar(irString);
                irCallInst = new IrCallInst("putstr", irString.getParam());
            }
            irinstructions.add(irCallInst);
        }
    }

    public void handleIRStmtExp(StmtExp stmtExp)
    {
        Exp exp = stmtExp.getExp();
        handleIRExp(exp, false);
    }

    public ArrayList<IrBasicBlock> handleCondExp(ArrayList<IrBasicBlock> basicBlocks)
    {
        LOrExp lOrExp = condExp.getExp();
        ArrayList<LAndExp> lAndExps = lOrExp.getExps();
        ArrayList<Token> ops = lOrExp.getOps();
        handleIRLAndExp(basicBlocks, lAndExps.get(0), 0);
        if (!ops.isEmpty())
        {
            int num = 0;
            for (int i = 0; i < ops.size(); i++)
            {
                num += lAndExps.get(i).getExps().size();
                handleIRLAndExp(basicBlocks, lAndExps.get(i + 1), num);
            }
        }
        return basicBlocks;
    }

    public void handleIRLAndExp(ArrayList<IrBasicBlock> basicBlocks, LAndExp lAndExp, int num)
    {
        ArrayList<EqExp> eqExps = lAndExp.getExps();
        ArrayList<Token> ops = lAndExp.getOps();
        IrBasicBlock basicBlock = basicBlocks.get(num);
        IrBlockInfo irBlockInfo = basicBlock.getIrBlockInfo();
        basicBlock.addIrInstruction(irBlockInfo);
        setIrBasicBlock(basicBlock);
        IrValue first = handleIREqExp(basicBlocks, eqExps.get(0), num);
        IrValue value_0 = new IrValue(IrType.i32, "0");
        IrCompareInst irCompareInst = new IrCompareInst(getAValue(), IrCompareInst.Type.Neq, IrType.i32, first, value_0);
        //todo
        //跳转语句
        IrBranchInst irBranchInst = new IrBranchInst(IrType.i1, irCompareInst, basicBlocks.get(num + 1), basicBlocks.get(basicBlocks.size() - 1));
        basicBlocks.get(num + 1).addPreds(basicBlock);
        basicBlocks.get(basicBlocks.size() - 1).addPreds(basicBlock);
        basicBlock.addIrInstruction(irCompareInst);
        basicBlock.addIrInstruction(irBranchInst);
        if (!ops.isEmpty())
        {
            int num_new = num;
            for (int i = 0; i < ops.size(); i++)
            {
                num_new += i;
                if (ops.get(i).getType() == Token.Type.AND)
                {
                    handleIREqExp(basicBlocks, eqExps.get(i + 1), num_new);
                }
                else
                {
                    handleIREqExp(basicBlocks, eqExps.get(i + 1), num_new);
                }
            }
        }
    }

    public IrValue handleIREqExp(ArrayList<IrBasicBlock> basicBlocks, EqExp eqExp, int num)
    {
        ArrayList<RelExp> relExps = eqExp.getExps();
        ArrayList<Token> ops = eqExp.getOps();
        IrBasicBlock basicBlock = basicBlocks.get(num);
        IrBlockInfo irBlockInfo = basicBlock.getIrBlockInfo();
        basicBlock.addIrInstruction(irBlockInfo);
        setIrBasicBlock(basicBlock);
        IrValue first = handleRelExp(relExps.get(0), basicBlock);
        IrValue value_0 = new IrValue(IrType.i32, "0");
        IrCompareInst irCompareInst = new IrCompareInst(getAValue(), IrCompareInst.Type.Neq, IrType.i32, first, value_0);
        //todo
        //跳转语句
        IrBranchInst irBranchInst = new IrBranchInst(IrType.i1, irCompareInst, basicBlocks.get(basicBlocks.size() - 1), basicBlocks.get(num + 1));
        basicBlocks.get(num + 1).addPreds(basicBlock);
        basicBlocks.get(basicBlocks.size() - 1).addPreds(basicBlock);
        basicBlock.addIrInstruction(irCompareInst);
        basicBlock.addIrInstruction(irBranchInst);
        if (ops.isEmpty())
        {
            return first;
        }
        else
        {
            IrValue exp1 = first;
            IrValue exp2 = null;
            for (int i = 0; i < ops.size(); i++)
            {
                exp2 = handleRelExp(relExps.get(i + 1), basicBlock);
                if (exp1.getValueType() == IrType.i8)
                {
                    String value = getAValue();
                    IrZext irZext = new IrZext(IrType.i8, value, exp1, IrType.i32);
                    basicBlock.addIrInstruction(irZext);
                    exp1 = irZext;
                }
                if (exp2.getValueType() == IrType.i8)
                {
                    String value = getAValue();
                    IrZext irZext = new IrZext(IrType.i8, value, exp2, IrType.i32);
                    basicBlock.addIrInstruction(irZext);
                    exp2 = irZext;
                }
                IrCompareInst irCompareInst1 = null;
                if (ops.get(i).getType() == Token.Type.EQL)
                {
                    irCompareInst1 = new IrCompareInst(getAValue(), IrCompareInst.Type.Eq, IrType.i32, exp1, exp2);
                }
                else if (ops.get(i).getType() == Token.Type.NEQ)
                {
                    irCompareInst1 = new IrCompareInst(getAValue(), IrCompareInst.Type.Neq, IrType.i32, exp1, exp2);
                }
                basicBlock.addIrInstruction(irCompareInst1);
                exp1 = irCompareInst1;
                first = irCompareInst1;
            }
            return first;
        }
    }

    public IrValue handleRelExp(RelExp relExp, IrBasicBlock basicBlock)
    {
        ArrayList<AddExp> addExps = relExp.getExps();
        ArrayList<Token> ops = relExp.getOps();
        IrValue first = handleIRAddExp(addExps.get(0), false);
        if (ops.isEmpty())
        {
            return first;
        }
        else
        {
            IrValue exp1 = first;
            IrValue exp2 = null;
            for (int i = 0; i < ops.size(); i++)
            {
                exp2 = handleIRAddExp(addExps.get(i + 1), false);
                if (exp1.getValueType() == IrType.i8)
                {
                    String value = getAValue();
                    IrZext irZext = new IrZext(IrType.i8, value, exp1, IrType.i32);
                    basicBlock.addIrInstruction(irZext);
                    exp1 = irZext;
                }
                if (exp2.getValueType() == IrType.i8)
                {
                    String value = getAValue();
                    IrZext irZext = new IrZext(IrType.i8, value, exp2, IrType.i32);
                    basicBlock.addIrInstruction(irZext);
                    exp2 = irZext;
                }
                IrCompareInst irCompareInst1 = null;
                if (ops.get(i).getType() == Token.Type.GRE)
                {
                    irCompareInst1 = new IrCompareInst(getAValue(), IrCompareInst.Type.Gt, IrType.i32, exp1, exp2);
                }
                else if (ops.get(i).getType() == Token.Type.GEQ)
                {
                    irCompareInst1 = new IrCompareInst(getAValue(), IrCompareInst.Type.Ge, IrType.i32, exp1, exp2);
                }
                else if (ops.get(i).getType() == Token.Type.LSS)
                {
                    irCompareInst1 = new IrCompareInst(getAValue(), IrCompareInst.Type.Lt, IrType.i32, exp1, exp2);
                }
                else if (ops.get(i).getType() == Token.Type.LEQ)
                {
                    irCompareInst1 = new IrCompareInst(getAValue(), IrCompareInst.Type.Le, IrType.i32, exp1, exp2);
                }
                basicBlock.addIrInstruction(irCompareInst1);
                exp1 = irCompareInst1;
                first = irCompareInst1;
            }
            return first;
        }
    }

    public String getAValue()
    {
        if (irBasicBlock.getFunction().isMainFunc())
        {
            return IrArgument.getAValue();
        }
        else
        {
            return irBasicBlock.getFunction().getAValue();
        }
    }

    public void setIrBasicBlock(IrBasicBlock irBasicBlock)
    {
        this.irBasicBlock = irBasicBlock;
    }

    @Override
    public ArrayList<String> irOutput()
    {
        return null;
    }
}
