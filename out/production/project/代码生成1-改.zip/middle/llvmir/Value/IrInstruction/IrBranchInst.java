package middle.llvmir.Value.IrInstruction;

import middle.llvmir.Value.IrType;
import middle.llvmir.Value.IrValue;

import java.util.ArrayList;

public class IrBranchInst extends IrInstruction
{
    //br i1 <cond>, label <iftrue>, label <iffalse> |
    //br label <dest>
    private IrValue cond;
    private IrValue iftrue;
    private IrValue iffalse;

    private String brtrue;
    private String brfalse;

    public IrBranchInst(IrType type, IrValue cond, IrValue iftrue, IrValue iffalse)
    {
        super(type);
        this.cond = cond;
        this.iftrue = iftrue;
        this.iffalse = iffalse;
    }

    public IrBranchInst(IrType type, IrValue cond, String brtrue, String brfalse)
    {
        super(type);
        this.cond = cond;
        this.brtrue = brtrue;
        this.brfalse = brfalse;
    }

    @Override
    public ArrayList<String> irOutput()
    {
        ArrayList<String> strings = new ArrayList<>();
        return strings;
    }
}
