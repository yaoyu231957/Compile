package middle.llvmir.Value;

import frontend.Parser.expression.CondExp;
import frontend.Parser.expression.arithmeticalexp.EqExp;
import frontend.Parser.expression.arithmeticalexp.LAndExp;
import frontend.Parser.expression.arithmeticalexp.LOrExp;
import frontend.Parser.statement.Stmt;
import frontend.Parser.statement.StmtAll;
import frontend.Parser.statement.StmtIf;
import frontend.Parser.statement.block.BlockDecl;
import frontend.Parser.statement.block.BlockItem;
import frontend.Parser.statement.block.BlockStmt;
import frontend.Parser.statement.block.StmtBlock;
import frontend.Parser.statement.stmtfor.StmtFor;
import middle.llvmir.Value.GlobalValue.IrFunction;
import middle.llvmir.Value.IrInstruction.IrBlockInfo;
import middle.llvmir.Value.IrInstruction.IrInstruction;
import middle.semantic.SymbolTable;

import java.util.ArrayList;

public class IrBasicBlock extends IrValue
{
    private String name; // 块的名字（label），可能没有
    private boolean needName = false;
    private ArrayList<IrInstruction> instructions;
    private IrFunction function; // 父function
    private SymbolTable symbolTable;
    private IrBlockInfo irBlockInfo;
    private StmtAll stmtAll;
    private CondExp condExp;
    private Stmt stmtif;
    private Stmt stmtelse;
    private EqExp eqExp;
    private ArrayList<BlockItem> blockItems = null;
    private ArrayList<IrBasicBlock> basicBlocks = new ArrayList<>();

    public IrBasicBlock(String name)
    {
        super(IrType.i32);//todo
        this.name = name;
        this.instructions = new ArrayList<>();
    }

    public IrBasicBlock(SymbolTable symbolTable, StmtAll stmtAll)
    {
        super(IrType.i32);//todo
        this.symbolTable = symbolTable;
        this.stmtAll = stmtAll;
        this.instructions = new ArrayList<>();
    }

    public IrBasicBlock(SymbolTable symbolTable, CondExp condExp)
    {
        super(IrType.i32);//todo
        this.symbolTable = symbolTable;
        this.condExp = condExp;
    }

    public IrBasicBlock(SymbolTable symbolTable, EqExp eqExp)
    {
        super(IrType.i32);//todo
        this.symbolTable = symbolTable;
        this.eqExp = eqExp;
    }

    public void addIrInstruction(IrInstruction instruction)
    {
        this.instructions.add(instruction);
    }

    public void addAllIrInstruction(ArrayList<IrInstruction> instructions)
    {
        this.instructions.addAll(instructions);
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getName()
    {
        return name;
    }

    public void setNeedName(boolean needName)
    {
        this.needName = needName;
    }

    public boolean getNeedName()
    {
        return needName;
    }

    public ArrayList<IrBasicBlock> buildIrBasicBlock()
    {
        if (stmtAll instanceof StmtBlock)
        {
            /* 说明传入元素是Block */
            blockItems = ((StmtBlock) stmtAll).getBlockItems();
            return handleIRBlock();
        }
        else if (stmtAll instanceof StmtIf)
        {
            /* 说明传入元素是StmtIf */
            return handleIRIf();
//            ArrayList<IrBasicBlock> blocks = new ArrayList<>();
//            return blocks;
        }
        else if (stmtAll instanceof StmtFor)
        {
            return handleIRFor();
        }
        else
        {
            System.out.println("ERROR in IrBasicBlockItemBuilder : should not reach here");
        }
        return null;
    }

    private ArrayList<IrBasicBlock> handleIRBlock()
    {
        for (int i = 0; i < blockItems.size(); i++)
        {
            BlockItem blockItem = this.blockItems.get(i);
            if (blockItem instanceof BlockStmt)
            {
                /* 说明将要解析的元素是块类，会返回一个基本块列表 */
                /* 生成并进入新的符号表 */
                SymbolTable newSymbolTable = new SymbolTable(this.symbolTable);
                IrBasicBlock irBasicBlock = null;
                Stmt stmt = ((BlockStmt) blockItem).getStmt();
                StmtAll stmtEle = stmt.getStmt();
                if (stmtEle instanceof StmtBlock || stmtEle instanceof StmtIf || stmtEle instanceof StmtFor)
                {
                    irBasicBlock = new IrBasicBlock(newSymbolTable, stmtEle);
                    irBasicBlock.setFunction(function);
                    this.addAllIrBasicBlocks(irBasicBlock.buildIrBasicBlock());
                }
                else
                {
                    /* 说明将要解析的元素是指令，一直解析直到元素末尾或遇到块类元素 */
                    IrBasicBlock basicBlock = new IrBasicBlock("NO NAME");
                    basicBlock.setFunction(function);
                    /* 始终解析ptr指向的BlockItemEle，并加到当前的IrBasicBlock中，直到结束或遇到块类 */
                    IrInstruction irInstruction = new IrInstruction(basicBlock, symbolTable, blockItem);
                    ArrayList<IrInstruction> irInstructions = irInstruction.buildIrInstruction();
                    if (irInstructions != null && !irInstructions.isEmpty())
                    {
                        basicBlock.addAllIrInstruction(irInstructions);
                    }
                    basicBlocks.add(basicBlock);
                }
            }
            else if (blockItem instanceof BlockDecl)
            {
                IrBasicBlock basicBlock = new IrBasicBlock("NO NAME");
                /* 始终解析ptr指向的BlockItemEle，并加到当前的IrBasicBlock中，直到结束或遇到块类 */
                basicBlock.setFunction(function);
                IrInstruction irInstruction = new IrInstruction(basicBlock, symbolTable, blockItem);
                ArrayList<IrInstruction> irInstructions = irInstruction.buildIrInstruction();
                if (irInstructions != null && !irInstructions.isEmpty())
                {
                    basicBlock.addAllIrInstruction(irInstructions);
                }
                basicBlocks.add(basicBlock);
            }
        }
        return basicBlocks;
    }

    private ArrayList<IrBasicBlock> handleIRIf()
    {
        //todo
        StmtIf stmtIf = (StmtIf) stmtAll;
        ArrayList<IrBasicBlock> basicBlocks_if = new ArrayList<>();

        //最开始
        IrBasicBlock basicBlock_start = new IrBasicBlock("if-start");
        basicBlock_start.setNeedName(true);
        basicBlock_start.setFunction(function);
        IrBlockInfo blockInfo = new IrBlockInfo(IrType.i32, basicBlock_start);
        basicBlock_start.setIrBlockInfo(blockInfo);
        basicBlocks_if.add(basicBlock_start);

        //Cond
        CondExp condExp = stmtIf.getCondExp();
        handleIRCondExp(condExp, basicBlocks_if);

        Stmt stmt_if = stmtIf.getStmt1();
        Stmt stmt_else = stmtIf.getStmt2();

        //if-true语句
        IrBasicBlock basicBlock_stmt_if = new IrBasicBlock(symbolTable, stmt_if.getStmt());
        basicBlock_stmt_if.setFunction(function);
        IrBlockInfo blockInfo_if = new IrBlockInfo(IrType.i32, basicBlock_stmt_if);
        basicBlock_stmt_if.setNeedName(true);
        basicBlock_stmt_if.setIrBlockInfo(blockInfo_if);
        basicBlocks_if.add(basicBlock_stmt_if);
        IrInstruction irInstruction_stmt_if = new IrInstruction(basicBlock_stmt_if, symbolTable, stmt_if);
        basicBlock_stmt_if.addAllIrInstruction(irInstruction_stmt_if.buildIrInstruction());

        //else-false语句
        if (stmt_else != null)
        {
            IrBasicBlock basicBlock_stmt_else = new IrBasicBlock(symbolTable, stmt_else.getStmt());
            basicBlock_stmt_else.setFunction(function);
            IrBlockInfo blockInfo_else = new IrBlockInfo(IrType.i32, basicBlock_stmt_else);
            basicBlock_stmt_else.setIrBlockInfo(blockInfo_else);
            basicBlocks_if.add(basicBlock_stmt_else);
            IrInstruction irInstruction_stmt_else = new IrInstruction(basicBlock_stmt_else, symbolTable, stmt_else);
            basicBlock_stmt_else.addAllIrInstruction(irInstruction_stmt_else.buildIrInstruction());
        }
        //得到所有块后再处理跳转
        handleIRCond(basicBlocks_if, condExp);
        return basicBlocks;
    }

    private ArrayList<IrBasicBlock> handleIRFor()
    {
        //todo
        return basicBlocks;
    }

    private void handleIRCond(ArrayList<IrBasicBlock> basicBlocks, CondExp condExp)
    {
        IrInstruction irInstruction_cond = new IrInstruction(symbolTable, condExp);
        basicBlocks.addAll(irInstruction_cond.handleCondExp(basicBlocks));
    }

    public void handleIRCondExp(CondExp condExp, ArrayList<IrBasicBlock> basicBlocks)
    {
        LOrExp lOrExp = condExp.getExp();
        ArrayList<LAndExp> lAndExps = lOrExp.getExps();
        for (int i = 0; i < lAndExps.size(); i++)
        {
            ArrayList<EqExp> eqExps = lAndExps.get(i).getExps();
            for (int j = 0; j < eqExps.size(); j++)
            {
                IrBasicBlock basicBlock = new IrBasicBlock(i + "-" + j);
                IrBlockInfo blockInfo = new IrBlockInfo(IrType.i32, basicBlock);
                basicBlock.setNeedName(true);
                basicBlock.setIrBlockInfo(blockInfo);
                basicBlock.setFunction(function);
                basicBlocks.add(basicBlock);
            }
        }
    }

    @Override
    public ArrayList<String> irOutput()
    {
        ArrayList<String> ret = new ArrayList<>();
        for (IrInstruction instruction : this.instructions)
        {
            ArrayList<String> temp = instruction.irOutput();
            if (temp != null && temp.size() != 0)
            {
                ret.addAll(temp);
            }
        }
        return ret;
    }

    public ArrayList<IrInstruction> getInstructions()
    {
        return this.instructions;
    }

    private void addAllIrBasicBlocks(ArrayList<IrBasicBlock> blocks)
    {
        this.basicBlocks.addAll(blocks);
    }

    public IrFunction getFunction()
    {
        return function;
    }

    public void setFunction(IrFunction irFunction)
    {
        this.function = irFunction;
    }

    public IrBlockInfo getIrBlockInfo()
    {
        return irBlockInfo;
    }

    public void setIrBlockInfo(IrBlockInfo irBlockInfo)
    {
        this.irBlockInfo = irBlockInfo;
    }

    public void addPreds(IrValue pred)
    {
        irBlockInfo.addPreds(pred);
    }
}
