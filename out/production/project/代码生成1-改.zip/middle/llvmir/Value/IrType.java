package middle.llvmir.Value;

public enum IrType
{
    i32, i8, i1, n_i32, n_i8, Void
}
