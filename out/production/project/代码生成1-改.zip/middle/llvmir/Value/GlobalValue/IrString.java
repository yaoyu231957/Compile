package middle.llvmir.Value.GlobalValue;

import middle.llvmir.Value.IrType;

import java.util.ArrayList;

public class IrString extends IrGlobalVar
{

    //<name> = private unnamed_addr constant [<num> x i8] c"<value>", align 1
    private String name;
    private String value;
    private int length;

    private static int count = -1;
    private static boolean has_n = false;
    private static IrString irString;

    public IrString(String value)
    {
        super(IrType.n_i8, null, true, value);
        this.name = getAName();
        this.length = value.length() + 1;
        if (value.equals("\\n"))
        {
            has_n = true;
        }
        if (value.contains("\\n"))
        {
            this.length--;
        }
        //value = value.replace("\n", "\\0A");
        value = value.replace("\\n", "\\0A");
        this.value = value;
    }

    public ArrayList<String> irOutput()
    {
        StringBuilder sb = new StringBuilder();
        sb.append("@" + name);
        sb.append(" = private unnamed_addr constant [");
        sb.append(length);
        sb.append(" x i8] c\"");
        sb.append(value + "\\00");
        sb.append("\", align 1\n");
        ArrayList<String> ret = new ArrayList<>();
        ret.add(sb.toString());
        return ret;
    }

    public static String getAName()
    {
        count++;
        if (count == 0)
        {
            return ".str";
        }
        else
        {
            return ".str." + count;
        }
    }

    public String getParam()
    {
        //i8* getelementptr inbounds ([7 x i8], [7 x i8]* @.str, i64 0, i64 0)
        return "i8* getelementptr inbounds ([" + length + " x i8], [" + length + " x i8]* @" + name + ", i64 0,i64 0)";
    }

    public static boolean getHas_n()
    {
        return has_n;
    }

    public static void setIrString(IrString irString)
    {
        IrString.irString = irString;
    }

    public static IrString getIrString()
    {
        return irString;
    }
}
