import frontend.Errors;
import frontend.Lexer;
import frontend.Token;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.IOException;
import java.util.ArrayList;

public class Compiler
{


    public static void main(String[] args)
    {
        try
        {
            String content = Files.readString(Paths.get("testfile.txt"));
            Lexer lexer = new Lexer(content);
            lexer.LexicalAnalysis();

            if (lexer.getErrorflag() == 0)
            {
                    try (PrintWriter writer = new PrintWriter(new FileWriter("lexer.txt")))
                    {
                        ArrayList<Token> tokenList = lexer.getTokenlist();
                        for (Token token : tokenList)
                        {
                            writer.println(token.getType() + " " + token.getContent());
                        }
                    }
                    catch (IOException e)
                    {
                        System.out.println("Output Error!");
                    }
            }
            else
            {
                    try (PrintWriter writer = new PrintWriter(new FileWriter("error.txt")))
                    {
                        ArrayList<Errors> errorlist = lexer.getErrorlist();
                        for (Errors error : errorlist)
                        {
                            writer.println(error.getLine() + " " + error.getType());
                        }
                    }
                    catch (IOException e)
                    {
                        System.out.println("Output Error!");
                    }
                }
        }
        catch (IOException e)
        {
            System.out.println("File Open Error!");
        }
    }

}