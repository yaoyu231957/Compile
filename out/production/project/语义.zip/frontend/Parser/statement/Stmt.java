package frontend.Parser.statement;

import frontend.Parser.expression.primaryexp.LVal;
import frontend.Parser.statement.block.StmtBlock;
import frontend.Parser.statement.stmtfor.StmtFor;
import frontend.Parser.statement.stmtreturn.StmtReturn;
import frontend.lexer.Token;
import frontend.lexer.Tokenlist;

public class Stmt
{
    private String type = "<Stmt>";
    private StmtAll stmt;

    public Stmt(StmtAll stmt)
    {
        this.stmt = stmt;
    }

    public Stmt ParseStmt(Tokenlist tokenlist, boolean flag)
    {
        StmtAll stmtAll = null;
        Token token = tokenlist.getToken();
        switch (token.getType())
        {
            case SEMICN:
                StmtExp stmtExp = new StmtExp(null, null);
                stmtAll = stmtExp.ParseStmtExp(tokenlist, flag);
                break;
            case IFTK:
                StmtIf stmtIf = new StmtIf(null, null, null, null, null, null, null);
                stmtAll = stmtIf.ParseStmtIf(tokenlist, flag);
                break;
            case FORTK:
                StmtFor stmtFor = new StmtFor(null, null, null, null, null, null, null, null);
                stmtAll = stmtFor.ParseStmtFor(tokenlist, flag);
                break;
            case BREAKTK:
                StmtBreak stmtBreak = new StmtBreak(null, null);
                stmtAll = stmtBreak.ParseStmtBreak(tokenlist, flag);
                break;
            case CONTINUETK:
                StmtContinue stmtContinue = new StmtContinue(null, null);
                stmtAll = stmtContinue.ParseStmtContinue(tokenlist, flag);
                break;
            case RETURNTK:
                StmtReturn stmtReturn = new StmtReturn(null, null, null);
                stmtAll = stmtReturn.ParseStmtReturn(tokenlist, flag);
                break;
            case PRINTFTK:
                StmtPrintf stmtPrintf = new StmtPrintf(null, null, null, null, null, null, null);
                stmtAll = stmtPrintf.ParseStmtPrintf(tokenlist, flag);
                break;
            case LBRACE:
                StmtBlock stmtBlock = new StmtBlock(null, null, null);
                stmtAll = stmtBlock.ParseStmtBlock(tokenlist, true, flag);
                break;
            case IDENFR:
                stmtAll = HandleIdent(tokenlist, flag);
                break;
            case LPARENT:
            case PLUS:
            case MINU:
            case INTCON:
            case CHRCON:
                StmtExp stmtExp1 = new StmtExp(null, null);
                stmtAll = stmtExp1.ParseStmtExp(tokenlist, flag);
                break;
            default:
                System.out.println(token.getType() + "  没有对应的Stmt");
        }
        return new Stmt(stmtAll);
    }

    private StmtAll HandleIdent(Tokenlist tokenlist, boolean flag)
    {
        int count = tokenlist.getCur_pos();
        //int mode = 0;
        //boolean flag = false;
        StmtAll stmtAll;
        Token token = tokenlist.getToken();
        if (tokenlist.getNextToken().getType() == Token.Type.LPARENT)
        {
            StmtExp stmtExp1 = new StmtExp(null, null);
            stmtAll = stmtExp1.ParseStmtExp(tokenlist, flag);
        }
        else
        {
            LVal lVal1 = new LVal(null, null, null, null);
            LVal lVal2 = lVal1.ParseLVal(tokenlist, false);
            if (tokenlist.getToken().getType() == Token.Type.ASSIGN && (tokenlist.getNextToken().getType() == Token.Type.GETINTTK || tokenlist.getNextToken().getType() == Token.Type.GETCHARTK))
            {
                tokenlist.ChangeCur_pos(count);
                StmtGet stmtGet = new StmtGet(null, null, null, null, null, null);
                stmtAll = stmtGet.ParseStmtGet(tokenlist, flag);
            }
            else if (tokenlist.getToken().getType() == Token.Type.ASSIGN)
            {
                tokenlist.ChangeCur_pos(count);
                StmtAssign stmtAssign = new StmtAssign(null, null, null, null);
                stmtAll = stmtAssign.ParseAssign(tokenlist, flag);
            }
            else
            {
                tokenlist.ChangeCur_pos(count);
                StmtExp stmtExp1 = new StmtExp(null, null);
                stmtAll = stmtExp1.ParseStmtExp(tokenlist, flag);
            }
            /*
            while (token.getType() != Token.Type.SEMICN && tokenlist.getCur_pos() + 1 < tokenlist.getTokenlist().size())
            {
                tokenlist.ReadNext();
                token = tokenlist.getToken();
                count += 1;
                if (token.getType() == Token.Type.ASSIGN)
                {
                    flag = true;
                }
                if (token.getType() == Token.Type.GETINTTK || token.getType() == Token.Type.GETCHARTK)
                {
                    mode = 1;
                }
            }
            tokenlist.ChangeCur_pos(count);
            if (flag)
            {
                if (mode == 1)
                {
                    StmtGet stmtGet = new StmtGet(null, null, null, null, null, null);
                    stmtAll = stmtGet.ParseStmtGet(tokenlist);
                }
                else
                {
                    StmtAssign stmtAssign = new StmtAssign(null, null, null, null);
                    stmtAll = stmtAssign.ParseAssign(tokenlist);
                }
            }

             */
        }
        return stmtAll;
    }

    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        sb.append(stmt.toString());
        sb.append(type + "\n");
        return sb.toString();
    }
}
