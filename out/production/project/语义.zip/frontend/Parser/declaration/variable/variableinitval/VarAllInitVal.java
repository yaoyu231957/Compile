package frontend.Parser.declaration.variable.variableinitval;

public interface VarAllInitVal
{
    public String toString();
}
