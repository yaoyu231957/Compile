package frontend.Parser.expression.unaryexp;

public interface UnaryAll
{
    public String toString();

    public String getValuetype();
}
