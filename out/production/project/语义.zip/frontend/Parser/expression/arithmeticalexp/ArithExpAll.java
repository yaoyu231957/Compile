package frontend.Parser.expression.arithmeticalexp;

public interface ArithExpAll
{
}
