package frontend.Parser.expression;

public interface AllExp
{
    public String toString();
}
