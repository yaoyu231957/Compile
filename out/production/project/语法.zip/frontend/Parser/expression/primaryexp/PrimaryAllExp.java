package frontend.Parser.expression.primaryexp;

public interface PrimaryAllExp
{
    public String toString();
}
