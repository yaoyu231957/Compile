package frontend.Parser.statement;

public interface StmtAll
{
    public String toString();
}
